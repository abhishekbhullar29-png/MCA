# FoodFlow React — Full-stack Food Ordering Website

Responsive React + Vite frontend and Express API. Includes 132 menu items, login/register, cart and checkout, order history, customer profile, admin dashboard, menu management and order status management.

## Requirements
- Node.js 18+ (Node 20 LTS recommended)
- npm
- Optional: MongoDB Community Server or MongoDB Atlas connection string

## Run locally
Open a terminal in this folder:

```powershell
npm install
npm --prefix client install
npm run dev
```

Open **http://localhost:5173** for the React website. Express API runs on **http://localhost:3000**.

## MongoDB setup (recommended)
1. Install and start MongoDB locally, or create a database in MongoDB Atlas.
2. Copy `.env.example` to `.env`.
3. Set `MONGO_URI` to your MongoDB connection string, for example:
   `MONGO_URI=mongodb://127.0.0.1:27017/foodflow`
4. Change `ADMIN_EMAIL` and `ADMIN_PASSWORD` to credentials you choose.
5. Restart `npm run dev`.

If `MONGO_URI` is not set or MongoDB cannot be reached, the app automatically uses local JSON files in `data/` so it can still be explored without MongoDB. MongoDB mode creates Mongoose models for users, products and orders and seeds the 132 menu items on first startup.

## Demo admin account
In JSON fallback mode, a demo administrator is created automatically:
- Email: `admin@foodflow.local`
- Password: `Admin123!`

When using MongoDB, set your own `ADMIN_EMAIL` and `ADMIN_PASSWORD` in `.env` before first startup. For a local learning demo only; change the default password before sharing or deploying.

Log in through the normal Login page. Admin users will see an **Admin** link and can open `/admin`.

## Features
- Separate Home, Menu, About, Contact, Login, Cart, My Orders, Order Details, Profile and Admin routes
- 132 menu items across 11 categories, search, category filtering, sorting and vegetarian-friendly filter
- Registration and login with bcrypt password hashing
- Profile editing for name, phone and default address
- Authenticated checkout and per-user order history
- Admin overview with product count, orders, revenue and active orders
- Admin can view all orders and change status: Confirmed, Preparing, Out for delivery, Delivered, Cancelled
- Admin can add, edit and hide menu items
- MongoDB persistence with Mongoose when `MONGO_URI` is configured; JSON fallback otherwise
- Responsive design, favourites toggle, contact and newsletter demo forms

## Production notes
This is an educational project, not production-ready. Sessions are in-memory and reset when the server restarts. Before deployment, use secure persistent sessions or JWTs with rotation, validate and rate-limit API requests, configure CORS/HTTPS, protect secrets, add audit logging, and use a real payment provider. Payment options are demo labels only. Contact/newsletter forms do not send email. Food photos use externally hosted Unsplash images.
