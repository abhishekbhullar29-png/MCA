require("dotenv").config();
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, "data");
fs.mkdirSync(DATA, { recursive: true });
const USERS_FILE = path.join(DATA, "users.json");
const ORDERS_FILE = path.join(DATA, "orders.json");
const PRODUCTS_FILE = path.join(DATA, "products.json");
const read = (p, fallback) => { try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch { return fallback; } };
const write = (p, data) => fs.writeFileSync(p, JSON.stringify(data, null, 2));
const sessions = new Map();
let dbMode = "json";
let jsonUsers = read(USERS_FILE, []);
let jsonOrders = read(ORDERS_FILE, []);
let jsonProducts = read(PRODUCTS_FILE, []);
let nextOrderId = Math.max(1000, ...jsonOrders.map(o => Number(o.id) || 0)) + 1;
let nextProductId = Math.max(0, ...jsonProducts.map(p => Number(p.id) || 0)) + 1;

const categories = [
  ["Pizza","🍕",[["Margherita Pizza",249],["Farmhouse Pizza",329],["Pepperoni Pizza",379],["Four Cheese Pizza",359],["Mexican Wave Pizza",319],["Paneer Tikka Pizza",339],["BBQ Chicken Pizza",389],["Veggie Supreme Pizza",349],["Peri Peri Pizza",329],["Classic Cheese Burst Pizza",399],["Mushroom Delight Pizza",299],["Olive & Corn Pizza",289]]],
  ["Burgers","🍔",[["Classic Veg Burger",129],["Crispy Chicken Burger",199],["Double Cheese Burger",189],["Paneer Crunch Burger",169],["Maharaja Burger",229],["Spicy Bean Burger",149],["BBQ Chicken Burger",219],["Aloo Tikki Burger",99],["Mushroom Swiss Burger",199],["Crispy Zinger Burger",209],["Peri Peri Burger",179],["Smoky Grill Burger",219]]],
  ["Indian","🍛",[["Paneer Butter Masala",279],["Dal Makhani",229],["Butter Chicken",329],["Chole Bhature",179],["Shahi Paneer",289],["Kadai Paneer",279],["Chicken Tikka Masala",349],["Rajma Chawal",159],["Palak Paneer",259],["Amritsari Kulcha",169],["Veg Biryani",219],["Chicken Biryani",289]]],
  ["Pasta","🍝",[["Alfredo White Sauce Pasta",229],["Arrabbiata Red Sauce Pasta",219],["Pesto Pasta",249],["Mac and Cheese",239],["Chicken Alfredo Pasta",299],["Paneer Tikka Pasta",259],["Spicy Pink Sauce Pasta",239],["Mushroom Cream Pasta",249],["Lasagna",299],["Garlic Parmesan Pasta",259],["Baked Veg Pasta",239],["Peri Peri Pasta",229]]],
  ["Chinese","🥡",[["Veg Hakka Noodles",169],["Chicken Hakka Noodles",219],["Veg Manchurian",189],["Chilli Paneer",229],["Chilli Chicken",269],["Veg Fried Rice",169],["Chicken Fried Rice",219],["Schezwan Noodles",189],["Spring Rolls",149],["Honey Chilli Potato",179],["Crispy Corn",169],["Dragon Chicken",289]]],
  ["Desserts","🍰",[["Chocolate Brownie",129],["New York Cheesecake",199],["Gulab Jamun",99],["Chocolate Lava Cake",149],["Tiramisu Cup",189],["Red Velvet Cake",179],["Classic Waffles",159],["Chocolate Sundae",149],["Rasmalai",119],["Blueberry Muffin",99],["Choco Chip Cookie",69],["Caramel Pudding",129]]],
  ["Drinks","🥤",[["Mango Smoothie",139],["Cold Coffee",129],["Fresh Lime Soda",79],["Masala Chai",49],["Iced Americano",119],["Strawberry Milkshake",149],["Mojito",129],["Orange Juice",99],["Chocolate Shake",149],["Peach Iced Tea",99],["Lassi",89],["Mineral Water",30]]],
  ["Healthy","🥗",[["Greek Salad",199],["Grilled Chicken Bowl",279],["Quinoa Veg Bowl",229],["Avocado Toast",219],["Caesar Salad",199],["Protein Power Bowl",259],["Paneer Salad",219],["Chickpea Buddha Bowl",229],["Grilled Veg Sandwich",159],["Oats & Fruit Bowl",169],["Corn & Bean Salad",179],["Sprout Chaat",119]]],
  ["Sandwiches","🥪",[["Club Sandwich",189],["Grilled Cheese Sandwich",139],["Paneer Tikka Sandwich",179],["Chicken Mayo Sandwich",199],["Corn Cheese Sandwich",159],["Bombay Masala Sandwich",149],["Tandoori Chicken Sandwich",219],["Egg Salad Sandwich",169],["Mushroom Melt Sandwich",179],["Veggie Delight Sandwich",149],["BBQ Paneer Sandwich",189],["Crispy Chicken Sub",229]]],
  ["Sides","🍟",[["French Fries",99],["Peri Peri Fries",119],["Cheese Garlic Bread",139],["Potato Wedges",109],["Mozzarella Sticks",169],["Chicken Nuggets",179],["Onion Rings",119],["Garlic Bread",99],["Loaded Nachos",189],["Cheese Balls",149],["Masala Papad",59],["Tandoori Momos",179]]],
  ["Breakfast","🥞",[["Pancake Stack",179],["Masala Omelette",99],["Poha",79],["Aloo Paratha",119],["Idli Sambar",99],["Masala Dosa",139],["French Toast",149],["Chole Kulche",129],["Veg Upma",79],["Egg Bhurji Toast",129],["Banana Pancakes",159],["Stuffed Paneer Paratha",139]]]
];
const images = {
 Pizza:"https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=900&q=85",
 Burgers:"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=85",
 Indian:"https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=900&q=85",
 Pasta:"https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=900&q=85",
 Chinese:"https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=900&q=85",
 Desserts:"https://images.unsplash.com/photo-1564355808539-22fda35bed7e?auto=format&fit=crop&w=900&q=85",
 Drinks:"https://images.unsplash.com/photo-1544145945-f90425340c7e?auto=format&fit=crop&w=900&q=85",
 Healthy:"https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=900&q=85",
 Sandwiches:"https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=900&q=85",
 Sides:"https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=900&q=85",
 Breakfast:"https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=900&q=85"
};
let seedFoods = [];
let fid = 1;
for (const [category, emoji, entries] of categories) {
  for (const [name, price] of entries) seedFoods.push({id:fid++,name,category,price,emoji,rating:Number((4.1+((fid*7)%9)/10).toFixed(1)),image:images[category],description:`Freshly prepared ${name.toLowerCase()} with quality ingredients.`,active:true});
}
if (!jsonProducts.length) { jsonProducts = seedFoods; write(PRODUCTS_FILE, jsonProducts); }
const UserSchema = new mongoose.Schema({
 name:{type:String,required:true}, email:{type:String,required:true,unique:true,lowercase:true}, phone:{type:String,default:""},
 passwordHash:{type:String,required:true}, role:{type:String,enum:["customer","admin"],default:"customer"},
 address:{type:String,default:""}, createdAt:{type:Date,default:Date.now}
});
const ProductSchema = new mongoose.Schema({
 name:{type:String,required:true}, category:{type:String,required:true}, price:{type:Number,min:0,required:true},
 rating:{type:Number,default:4.5}, image:{type:String,default:""}, emoji:{type:String,default:"🍽️"},
 description:{type:String,default:""}, active:{type:Boolean,default:true}
});
const OrderSchema = new mongoose.Schema({
 userId:{type:String,required:true,index:true}, customer:{name:String,phone:String,address:String,instructions:String},
 paymentMethod:{type:String,default:"Cash on Delivery"}, items:[mongoose.Schema.Types.Mixed],
 subtotal:Number,delivery:Number,tax:Number,total:Number,
 status:{type:String,enum:["Confirmed","Preparing","Out for delivery","Delivered","Cancelled"],default:"Confirmed"},
 createdAt:{type:Date,default:Date.now}, updatedAt:{type:Date,default:Date.now}
});
const User = mongoose.model("User",UserSchema);
const Product = mongoose.model("Product",ProductSchema);
const Order = mongoose.model("Order",OrderSchema);
const publicUser = u => ({id:String(u._id||u.id),name:u.name,email:u.email,phone:u.phone||"",address:u.address||"",role:u.role||"customer",createdAt:u.createdAt});
const allProducts = async () => dbMode==="mongo" ? (await Product.find({active:true}).lean()).map(p=>({...p,id:String(p._id)})) : jsonProducts.filter(p=>p.active!==false);
const findUserByEmail = async email => dbMode==="mongo" ? User.findOne({email:email.toLowerCase()}) : jsonUsers.find(u=>u.email===email.toLowerCase());
const findUserById = async id => dbMode==="mongo" ? User.findById(id) : jsonUsers.find(u=>u.id===id);
async function saveUser(user) {
 if(dbMode==="mongo") { await user.save(); return user; }
 const idx=jsonUsers.findIndex(u=>u.id===user.id); if(idx>=0)jsonUsers[idx]=user;else jsonUsers.push(user);write(USERS_FILE,jsonUsers);return user;
}
async function auth(req,res,next) {
 try {
  const token=(req.headers.authorization||"").replace(/^Bearer\s+/i,""); const uid=sessions.get(token);
  if(!uid)return res.status(401).json({message:"Please log in to continue."});
  const user=await findUserById(uid);if(!user)return res.status(401).json({message:"Please log in to continue."});
  req.user=user;req.token=token;next();
 } catch(e){res.status(500).json({message:"Authentication failed."});}
}
function adminOnly(req,res,next){if(req.user.role!=="admin")return res.status(403).json({message:"Admin access required."});next();}
app.use(cors());app.use(express.json({limit:"1mb"}));
app.get("/api/health",(req,res)=>res.json({ok:true,service:"FoodFlow",database:dbMode,itemCount:seedFoods.length}));
app.get("/api/foods",async(req,res)=>{try{let list=await allProducts();const q=String(req.query.search||"").toLowerCase(),cat=String(req.query.category||"All");if(cat!=="All")list=list.filter(f=>f.category===cat);if(q)list=list.filter(f=>`${f.name} ${f.category} ${f.description}`.toLowerCase().includes(q));res.json(list)}catch(e){res.status(500).json({message:"Could not load menu."})}});
app.get("/api/categories",async(req,res)=>{try{const list=await allProducts();res.json(["All",...new Set(list.map(f=>f.category))])}catch(e){res.json(["All",...categories.map(c=>c[0])])}});
app.post("/api/auth/register",async(req,res)=>{try{
 const {name,email,password,phone=""}=req.body||{};if(!name?.trim()||!email?.trim()||!password)return res.status(400).json({message:"Name, email and password are required."});if(String(password).length<6)return res.status(400).json({message:"Password must be at least 6 characters."});
 const normalized=email.trim().toLowerCase();if(await findUserByEmail(normalized))return res.status(409).json({message:"Email already registered. Please log in."});
 let user;if(dbMode==="mongo")user=new User({name:name.trim(),email:normalized,phone:String(phone).trim(),passwordHash:await bcrypt.hash(password,10),role:"customer"});else user={id:crypto.randomUUID(),name:name.trim(),email:normalized,phone:String(phone).trim(),passwordHash:await bcrypt.hash(password,10),role:"customer",address:"",createdAt:new Date().toISOString()};
 await saveUser(user);const token=crypto.randomBytes(32).toString("hex");sessions.set(token,String(user._id||user.id));res.status(201).json({token,user:publicUser(user),message:"Account created."});
 }catch(e){res.status(500).json({message:"Could not create account."})}});
app.post("/api/auth/login",async(req,res)=>{try{const email=String(req.body?.email||"").trim().toLowerCase(),password=String(req.body?.password||"");const user=await findUserByEmail(email);if(!user||!(await bcrypt.compare(password,user.passwordHash)))return res.status(401).json({message:"Incorrect email or password."});const token=crypto.randomBytes(32).toString("hex");sessions.set(token,String(user._id||user.id));res.json({token,user:publicUser(user),message:"Welcome back!"})}catch(e){res.status(500).json({message:"Could not log in."})}});
app.get("/api/auth/me",auth,(req,res)=>res.json({user:publicUser(req.user)}));
app.patch("/api/profile",auth,async(req,res)=>{try{const {name,phone,address}=req.body||{};if(!name?.trim())return res.status(400).json({message:"Name is required."});if(dbMode==="mongo"){req.user.name=name.trim();req.user.phone=String(phone||"").trim();req.user.address=String(address||"").trim();await req.user.save()}else{req.user.name=name.trim();req.user.phone=String(phone||"").trim();req.user.address=String(address||"").trim();write(USERS_FILE,jsonUsers)}res.json({user:publicUser(req.user),message:"Profile updated."})}catch(e){res.status(500).json({message:"Could not update profile."})}});
app.post("/api/auth/logout",(req,res)=>{const token=(req.headers.authorization||"").replace(/^Bearer\s+/i,"");sessions.delete(token);res.json({message:"Logged out"})});
app.get("/api/orders",auth,async(req,res)=>{try{let list;if(dbMode==="mongo")list=await Order.find({userId:String(req.user._id)}).sort({createdAt:-1}).lean();else list=jsonOrders.filter(o=>o.userId===req.user.id).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));res.json(list.map(({userId,...o})=>({...o,id:String(o.id||o._id)})))}catch(e){res.status(500).json({message:"Could not load orders."})}});
app.post("/api/orders",auth,async(req,res)=>{try{
 const {customer,items,paymentMethod="Cash on Delivery"}=req.body||{};if(!customer?.name||!customer?.phone||!customer?.address)return res.status(400).json({message:"Please complete your delivery details."});if(!Array.isArray(items)||!items.length)return res.status(400).json({message:"Your cart is empty."});
 const products=await allProducts();const orderItems=items.map(i=>{const f=products.find(x=>String(x.id)===String(i.id)||String(x._id)===String(i.id));if(!f)return null;const quantity=Math.max(1,Math.min(99,Number(i.quantity)||1));return {...f,id:String(f.id||f._id),quantity,subtotal:f.price*quantity}}).filter(Boolean);if(!orderItems.length)return res.status(400).json({message:"No valid food items."});
 const subtotal=orderItems.reduce((s,i)=>s+i.subtotal,0),delivery=subtotal>=499?0:49,tax=Math.round(subtotal*.05),base={userId:String(req.user._id||req.user.id),customer,paymentMethod,items:orderItems,subtotal,delivery,tax,total:subtotal+delivery+tax,status:"Confirmed",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};
 let order;if(dbMode==="mongo"){order=await Order.create(base);order=order.toObject();order.id=String(order._id)}else{order={...base,id:nextOrderId++};jsonOrders.unshift(order);write(ORDERS_FILE,jsonOrders)}
 const {userId,...safe}=order;res.status(201).json({message:"Order placed successfully",order:safe});
 }catch(e){res.status(500).json({message:"Could not place order."})}});
app.get("/api/orders/:id",auth,async(req,res)=>{try{let o;if(dbMode==="mongo"){o=await Order.findOne({_id:req.params.id,userId:String(req.user._id)}).lean();if(o)o.id=String(o._id)}else o=jsonOrders.find(x=>String(x.id)===req.params.id&&x.userId===req.user.id);if(!o)return res.status(404).json({message:"Order not found"});const {userId,...safe}=o;res.json(safe)}catch(e){res.status(404).json({message:"Order not found"})}});

// Admin-only API
app.get("/api/admin/summary",auth,adminOnly,async(req,res)=>{try{const products=await allProducts();let allOrders=dbMode==="mongo"?await Order.find({}).lean():jsonOrders;res.json({products:products.length,orders:allOrders.length,revenue:allOrders.filter(o=>o.status!=="Cancelled").reduce((s,o)=>s+Number(o.total||0),0),pending:allOrders.filter(o=>!["Delivered","Cancelled"].includes(o.status)).length,customers:dbMode==="mongo"?await User.countDocuments({role:"customer"}):jsonUsers.filter(u=>u.role==="customer").length})}catch(e){res.status(500).json({message:"Could not load admin summary."})}});
app.get("/api/admin/orders",auth,adminOnly,async(req,res)=>{try{let list=dbMode==="mongo"?await Order.find({}).sort({createdAt:-1}).lean():[...jsonOrders].sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt));res.json(list.map(o=>({...o,id:String(o.id||o._id)})))}catch(e){res.status(500).json({message:"Could not load all orders."})}});
app.patch("/api/admin/orders/:id/status",auth,adminOnly,async(req,res)=>{try{const allowed=["Confirmed","Preparing","Out for delivery","Delivered","Cancelled"],status=String(req.body?.status||"");if(!allowed.includes(status))return res.status(400).json({message:"Invalid order status."});let order;if(dbMode==="mongo"){order=await Order.findByIdAndUpdate(req.params.id,{status,updatedAt:new Date()},{new:true}).lean();if(order)order.id=String(order._id)}else{order=jsonOrders.find(o=>String(o.id)===req.params.id);if(order){order.status=status;order.updatedAt=new Date().toISOString();write(ORDERS_FILE,jsonOrders)}}if(!order)return res.status(404).json({message:"Order not found."});res.json({message:"Order status updated.",order})}catch(e){res.status(404).json({message:"Could not update order status."})}});
app.get("/api/admin/products",auth,adminOnly,async(req,res)=>{try{const list=dbMode==="mongo"?await Product.find({}).lean():jsonProducts;res.json(list.map(p=>({...p,id:String(p.id||p._id)})))}catch(e){res.status(500).json({message:"Could not load products."})}});
app.post("/api/admin/products",auth,adminOnly,async(req,res)=>{try{const {name,category,price,image,description,emoji="🍽️"}=req.body||{};if(!name?.trim()||!category?.trim()||!Number.isFinite(Number(price))||Number(price)<0)return res.status(400).json({message:"Name, category and valid price are required."});const item={name:name.trim(),category:category.trim(),price:Number(price),image:String(image||""),description:String(description||""),emoji,rating:4.5,active:true};let saved;if(dbMode==="mongo"){saved=await Product.create(item);saved=saved.toObject();saved.id=String(saved._id)}else{saved={...item,id:nextProductId++};jsonProducts.push(saved);write(PRODUCTS_FILE,jsonProducts)}res.status(201).json(saved)}catch(e){res.status(500).json({message:"Could not create product."})}});
app.patch("/api/admin/products/:id",auth,adminOnly,async(req,res)=>{try{const allowed=["name","category","price","image","description","active"];const updates={};for(const k of allowed)if(req.body[k]!==undefined)updates[k]=k==="price"?Number(req.body[k]):req.body[k];let p;if(dbMode==="mongo"){p=await Product.findByIdAndUpdate(req.params.id,updates,{new:true}).lean();if(p)p.id=String(p._id)}else{p=jsonProducts.find(x=>String(x.id)===req.params.id);if(p){Object.assign(p,updates);write(PRODUCTS_FILE,jsonProducts)}}if(!p)return res.status(404).json({message:"Product not found."});res.json(p)}catch(e){res.status(500).json({message:"Could not update product."})}});
app.delete("/api/admin/products/:id",auth,adminOnly,async(req,res)=>{try{let ok=false;if(dbMode==="mongo"){const p=await Product.findByIdAndUpdate(req.params.id,{active:false},{new:true});ok=!!p}else{const p=jsonProducts.find(x=>String(x.id)===req.params.id);if(p){p.active=false;write(PRODUCTS_FILE,jsonProducts);ok=true}}if(!ok)return res.status(404).json({message:"Product not found."});res.json({message:"Product hidden from menu."})}catch(e){res.status(500).json({message:"Could not remove product."})}});

const clientDist=path.join(__dirname,"client","dist");
if(fs.existsSync(clientDist)){app.use(express.static(clientDist));app.get("*",(req,res)=>res.sendFile(path.join(clientDist,"index.html")));}
async function start(){
 const uri=process.env.MONGO_URI;
 if(uri){try{await mongoose.connect(uri);dbMode="mongo";console.log("Connected to MongoDB");const count=await Product.countDocuments();if(!count){await Product.insertMany(seedFoods.map(({id,...p})=>p));console.log("Seeded menu items into MongoDB")}const adminEmail=(process.env.ADMIN_EMAIL||"admin@foodflow.local").toLowerCase();const adminPassword=process.env.ADMIN_PASSWORD||"Admin123!";let admin=await User.findOne({email:adminEmail});if(!admin){admin=await User.create({name:"FoodFlow Admin",email:adminEmail,passwordHash:await bcrypt.hash(adminPassword,10),role:"admin"});console.log(`Created demo admin: ${adminEmail}`)}else if(admin.role!=="admin"){admin.role="admin";await admin.save()} }catch(e){console.error("MongoDB connection failed; using JSON fallback:",e.message);dbMode="json"}}else{console.log("MONGO_URI not set — using local JSON storage. Set MONGO_URI to enable MongoDB.");if(!jsonUsers.some(u=>u.email==="admin@foodflow.local")){jsonUsers.push({id:crypto.randomUUID(),name:"FoodFlow Admin",email:"admin@foodflow.local",phone:"",passwordHash:await bcrypt.hash("Admin123!",10),role:"admin",address:"",createdAt:new Date().toISOString()});write(USERS_FILE,jsonUsers);console.log("Created demo admin account: admin@foodflow.local")}}
 app.listen(PORT,()=>console.log(`FoodFlow API running at http://localhost:${PORT} — ${seedFoods.length} menu items — DB: ${dbMode}`));
}
start();
